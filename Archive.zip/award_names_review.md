# Inferred Golden Globes Award Names (from tweets, no hard-coding)

## 01. Best Director  _(support: 106)_
- examples: Best Director; best director; Best director

## 02. Best motion picture drama  _(support: 91)_
- examples: Best motion picture drama; Best Motion Picture Drama

## 03. Best supporting actress in a motion picture is  _(support: 79)_
- examples: Best supporting actress in a motion picture is; Best Supporting Actress in a Motion Picture; Best supporting actress in a motion picture; Best Supporting Actress In A Motion Picture

## 04. Best director motion picture  _(support: 63)_
- examples: Best director motion picture; Best Director - Motion Picture

## 05. Best Screenplay  _(support: 53)_
- examples: Best Screenplay; Best screenplay; best screenplay

## 06. Best supporting actor, motion picture  _(support: 50)_
- examples: Best supporting actor, motion picture

## 07. best supporting actress  _(support: 50)_
- examples: best supporting actress; Best Supporting Actress; Best supporting actress

## 08. Best Director for  _(support: 45)_
- examples: Best Director for; best director for; BEST DIRECTOR FOR

## 09. best original song for  _(support: 43)_
- examples: best original song for; Best Original Song for

## 10. Best Actress  _(support: 40)_
- examples: Best Actress; best actress; BEST ACTRESS; Best actress

## 11. best supporting actress for  _(support: 34)_
- examples: best supporting actress for; Best Supporting Actress for; Best Supporting Actress For

## 12. Best Supporting Actress in a Motion Picture for  _(support: 34)_
- examples: Best Supporting Actress in a Motion Picture for

## 13. best picture, musical or comedy  _(support: 34)_
- examples: best picture, musical or comedy

## 14. Best animated feature film is  _(support: 33)_
- examples: Best animated feature film is

## 15. best supporting actor  _(support: 33)_
- examples: best supporting actor; Best Supporting Actor; Best supporting actor; Best Supporting Actr

## 16. Best Actor, Drama  _(support: 30)_
- examples: Best Actor, Drama; Best Actor Drama; best actor drama

## 17. Best actress in a TV comedy or musical  _(support: 29)_
- examples: Best actress in a TV comedy or musical

## 18. best – picture Golden Globes  _(support: 29)_
- examples: best-picture Golden Globes

## 19. Best Original Song  _(support: 27)_
- examples: Best Original Song; best original song; Best original song; BEST ORIGINAL SONG

## 20. Best Picture nominee Lincoln  _(support: 26)_
- examples: Best Picture nominee Lincoln

## 21. Best Supporting Actress in a TV Series  _(support: 25)_
- examples: Best Supporting Actress in a TV Series; Best Supporting Actress in a Television Series; Best Supporting Actress in a TV series

## 22. best actor for  _(support: 25)_
- examples: best actor for; Best Actor for; Best Actor For

## 23. best actor, drama for  _(support: 24)_
- examples: best actor, drama for

## 24. best supporting actor at  _(support: 22)_
- examples: best supporting actor at

## 25. Best supporting actress TV series, miniseries, or TV movie  _(support: 22)_
- examples: Best supporting actress TV series, miniseries, or TV movie

## 26. best actress in TV drama, rubs in her  _(support: 22)_
- examples: best actress in TV drama, rubs in her

## 27. Best Supporting Actor in  _(support: 21)_
- examples: Best Supporting Actor in

## 28. Best Supporting Actor Globe for  _(support: 20)_
- examples: Best Supporting Actor Globe for

## 29. Best Supporting Actress in  _(support: 20)_
- examples: Best Supporting Actress in

## 30. Best director for motion picture  _(support: 20)_
- examples: Best director for motion picture; Best Director - Motion Picture for

## 31. best supporting actress http  _(support: 19)_
- examples: best supporting actress http

## 32. Best Actor  _(support: 18)_
- examples: Best Actor; best actor; Best actor

## 33. Best original score – motion picture is  _(support: 18)_
- examples: Best original score - motion picture is

## 34. best actress at the  _(support: 18)_
- examples: best actress at the

## 35. Best Director for Argo  _(support: 18)_
- examples: Best Director for Argo; best director for Argo; Best Director for ARGO; Best director for ARGO

## 36. Best actor in a miniseries/TV movie  _(support: 17)_
- examples: Best actor in a miniseries/TV movie

## 37. Best Actress Award  _(support: 17)_
- examples: Best Actress Award

## 38. Best Motion Picture  _(support: 17)_
- examples: Best Motion Picture; best motion picture; Best motion picture

## 39. best actress in a comedy or musical  _(support: 17)_
- examples: Best Actress in Musical or Comedy; Best Actress in Comedy or Musical; best actress in a comedy or musical; Best Actress in a Comedy or Musical

## 40. best actress for  _(support: 16)_
- examples: best actress for; Best Actress for

## 41. Best Comedy Actor In A Television Series  _(support: 16)_
- examples: Best Comedy Actor In A Television Series

## 42. best screenplay for  _(support: 15)_
- examples: best screenplay for; Best Screenplay for; Best Screenplay For

## 43. Best Motion Picture, comedy or musical  _(support: 15)_
- examples: Best Motion Picture, comedy or musical; Best Motion Picture Comedy or Musical; Best Motion Picture, Comedy or Musical

## 44. best screenplay for Django Unchained  _(support: 14)_
- examples: best screenplay for Django Unchained; Best Screenplay for Django Unchained; BEST SCREENPLAY FOR DJANGO UNCHAINED

## 45. best motion picture screenplay for  _(support: 14)_
- examples: best motion picture screenplay for

## 46. Best actor TV series – comedy or musical  _(support: 14)_
- examples: Best actor TV series - comedy or musical

## 47. best film director for  _(support: 14)_
- examples: best film director for

## 48. Best Actor in a Motion Picture Drama  _(support: 14)_
- examples: Best Actor in a Motion Picture Drama; Best actor in a motion picture drama; Best Actor in A Motion Picture Drama

## 49. Best Actor in a Motion Picture, Drama for  _(support: 14)_
- examples: Best Actor in a Motion Picture, Drama for

## 50. Best Supporting Actor for Django Unchained  _(support: 13)_
- examples: Best Supporting Actor for Django Unchained; best supporting actor for Django Unchained

## 51. Best actress in a mini – series/TV movie  _(support: 13)_
- examples: Best actress in a mini-series/TV movie; best actress in a mini-series/TV movie

## 52. Best Song at the  _(support: 13)_
- examples: Best Song at the; best song at the

## 53. Best Actress in a Comedy or Musical for  _(support: 13)_
- examples: Best Actress in a Comedy or Musical for; best actress in a comedy or musical for

## 54. best actor in a comedy or musical TV series for  _(support: 13)_
- examples: best actor in a comedy or musical TV series for

## 55. best actress in a comedy series  _(support: 13)_
- examples: best actress in a comedy series

## 56. best picture  _(support: 13)_
- examples: best picture; Best Picture; BEST PICTURE

## 57. Best actress in a motion picture drama  _(support: 13)_
- examples: Best actress in a motion picture drama; Best Actress in a Motion Picture Drama; best actress in a motion picture drama

## 58. best actress, drama, for  _(support: 13)_
- examples: best actress, drama, for; Best Actress, Drama, for

## 59. best supporting actor for  _(support: 12)_
- examples: best supporting actor for

## 60. best original song for motion picture http  _(support: 12)_
- examples: best original song for motion picture http

## 61. Best Actor in a TV Series, Comedy for  _(support: 12)_
- examples: Best Actor in a TV Series, Comedy for

## 62. Best Actress in a Motion Picture, Drama for  _(support: 12)_
- examples: Best Actress in a Motion Picture, Drama for

## 63. Best Actor Motion Picture – Drama for performance in  _(support: 12)_
- examples: Best Actor Motion Picture - Drama for performance in

## 64. best actor in a musical/comedy  _(support: 12)_
- examples: best actor in a musical/comedy; Best Actor in Musical/Comedy in; Best Actor in a Musical/Comedy

## 65. best actor who did not have sex with that woman  _(support: 11)_
- examples: best actor who did not have sex with that woman

## 66. Best Actress Motion Picture – Comedy or Musical at  _(support: 11)_
- examples: Best Actress Motion Picture - Comedy or Musical at

## 67. best actress in a comedy or musical movie for  _(support: 11)_
- examples: best actress in a comedy or musical movie for

## 68. Best Supporting Actress for Les Mis  _(support: 11)_
- examples: Best Supporting Actress for Les Mis

## 69. Best Actress in a Motion Picture, Comedy for Silver Linings Playbook  _(support: 11)_
- examples: Best Actress in a Motion Picture, Comedy for Silver Linings Playbook

## 70. Best Actor in a comedy or musical  _(support: 11)_
- examples: Best Actor in a comedy or musical; best actor in a comedy or musical

## 71. Best Actor in a Motion Picture  _(support: 11)_
- examples: Best Actor in a Motion Picture

## 72. best actor in a drama for Lincoln at the  _(support: 11)_
- examples: best actor in a drama for Lincoln at the

## 73. Best Song, unsurprisingly  _(support: 10)_
- examples: Best Song, unsurprisingly

## 74. Best Director and a standing ovation  _(support: 10)_
- examples: Best Director and a standing ovation

## 75. best actress in a drama at the  _(support: 10)_
- examples: best actress in a drama at the

## 76. Best Supporting Actor in a Motion Picture for his role in Django Unchained  _(support: 9)_
- examples: Best Supporting Actor in a Motion Picture for his role in Django Unchained

## 77. Best Actress in a Miniseries  _(support: 9)_
- examples: Best Actress in a Miniseries

## 78. best foreign film at  _(support: 9)_
- examples: best foreign film at

## 79. Best Actress in a Motion Picture – Drama at the  _(support: 9)_
- examples: Best Actress in a Motion Picture - Drama at the

## 80. Best Song  _(support: 8)_
- examples: Best Song; best song

## 81. best actress in a comedic or musical film  _(support: 8)_
- examples: best actress in a comedic or musical film

## 82. Best Actress in a Musical or Comedy Golden Globes 2013 http  _(support: 8)_
- examples: Best Actress in a Musical or Comedy Golden Globes 2013 http; Best  Actress in a Musical or Comedy Golden Globes 2013 http

## 83. Best Actress for Homeland  _(support: 8)_
- examples: Best Actress for Homeland

## 84. best actress in a drama series  _(support: 8)_
- examples: best actress in a drama series

## 85. Best Comedy/Musical  _(support: 8)_
- examples: Best Comedy/Musical; best comedy/musical

## 86. best actor in a musical or comedy award at  _(support: 8)_
- examples: best actor in a musical or comedy award at

## 87. Best Supporting Actress in a TV show  _(support: 7)_
- examples: Best Supporting Actress in a TV show

## 88. Best Supporting Actress in a TV Movie, Series, or Miniseries for  _(support: 7)_
- examples: Best Supporting Actress in a TV Movie, Series, or Miniseries for

## 89. Best Actress in a Miniseries or TV Movie for  _(support: 7)_
- examples: Best Actress in a Miniseries or TV Movie for

## 90. Best actor for TV drama  _(support: 7)_
- examples: Best actor for TV drama; best actor for TV drama

## 91. Best TV Series – Drama  _(support: 7)_
- examples: Best TV Series - Drama; Best TV series - Drama

## 92. Best Actor in a Mini – Series/TV Movie at the  _(support: 7)_
- examples: Best Actor in a Mini-Series/TV Movie at the

## 93. best actress in a comedy for Silver Linings Playbook  _(support: 7)_
- examples: best actress in a comedy for Silver Linings Playbook; Best Actress In A Comedy for Silver Linings Playbook

## 94. Best Actress in a Motion Picture  _(support: 7)_
- examples: Best Actress in a Motion Picture; Best actress in a motion picture; Best actress in a Motion Picture

## 95. Best Actress in a Comedy/Musical in  _(support: 7)_
- examples: Best Actress in a Comedy/Musical in

## 96. Best supporting actor in a TV show, miniseries or TV movie  _(support: 7)_
- examples: Best supporting actor in a TV show, miniseries or TV movie

## 97. Best Screenplay – Motion Picture at the  _(support: 7)_
- examples: Best Screenplay - Motion Picture at the

## 98. Best foreign film  _(support: 7)_
- examples: Best foreign film; Best Foreign Film

## 99. Best actress in a TV series, drama,  _(support: 7)_
- examples: Best actress in a TV series, drama,

## 100. best actress in a TV series – comedy or musical http  _(support: 7)_
- examples: best actress in a TV series - comedy or musical http

## 101. Best Comedy or Musical  _(support: 7)_
- examples: Best Comedy or Musical; best comedy or musical

## 102. best Best Television Comedy/Musical Series  _(support: 7)_
- examples: best Best Television Comedy/Musical Series

## 103. best actress in a dramatic film for  _(support: 7)_
- examples: best actress in a dramatic film for

## 104. Best Actor in a Motion Picture, Drama, for his role in Lincoln  _(support: 7)_
- examples: Best Actor in a Motion Picture, Drama, for his role in Lincoln

## 105. best actress in a mini – series or TV movie for  _(support: 6)_
- examples: best actress in a mini-series or TV movie for

## 106. best actress in mini – series/TV movie for  _(support: 6)_
- examples: best actress in mini-series/TV movie for

## 107. best actor for TV drama http  _(support: 6)_
- examples: best actor for TV drama http

## 108. Best Original Score  _(support: 6)_
- examples: Best Original Score

## 109. Best Original Song category, the Golden Globe  _(support: 6)_
- examples: Best Original Song category, the Golden Globe

## 110. best actress, motion picture comedy or musical, for  _(support: 6)_
- examples: best actress, motion picture comedy or musical, for

## 111. best actress in a comedy  _(support: 6)_
- examples: best actress in a comedy; Best Actress in a Comedy

## 112. Best supporting actor in TV  _(support: 6)_
- examples: Best supporting actor in TV

## 113. Best Supporting Actress for Les Miserables  _(support: 6)_
- examples: Best Supporting Actress for Les Miserables; best supporting actress for Les Miserables; Best Supporting Actress for LES MISERABLES

## 114. Best actress in a TV comedy/musical  _(support: 6)_
- examples: Best actress in a TV comedy/musical

## 115. best TV series – comedy or musical http  _(support: 6)_
- examples: best TV series - comedy or musical http

## 116. Best TV comedy/musical  _(support: 6)_
- examples: Best TV comedy/musical; Best TV Comedy/Musical

## 117. Best actor in a motion picture comedy/musical  _(support: 6)_
- examples: Best actor in a motion picture comedy/musical

## 118. best speech award  _(support: 6)_
- examples: best speech award

## 119. Best Supporting Actor in a Motion Picture  _(support: 5)_
- examples: Best Supporting Actor in a Motion Picture; Best supporting actor in a motion picture

## 120. best miniseries or TV movie  _(support: 5)_
- examples: best miniseries or TV movie; Best Miniseries or TV Movie; Best Miniseries or TV movie

## 121. best actress in miniseries/TV movie and first person to  _(support: 5)_
- examples: best actress in miniseries/TV movie and first person to

## 122. best actor in a miniseries  _(support: 5)_
- examples: best actor in a miniseries

## 123. best Hillary impression  _(support: 5)_
- examples: best Hillary impression

## 124. best actress in a musical/comedy for  _(support: 5)_
- examples: best actress in a musical/comedy for

## 125. Best actress in a motion picture comedy or musical  _(support: 5)_
- examples: Best actress in a motion picture comedy or musical

## 126. Best Actress In A Supporting Role in a Motion Picture the  _(support: 5)_
- examples: Best Actress In A Supporting Role in a Motion Picture the

## 127. best supporting actress, motion picture  _(support: 5)_
- examples: best supporting actress, motion picture

## 128. Best Picture I will throw myself off a bridge  _(support: 5)_
- examples: Best Picture I will throw myself off a bridge

## 129. Best Foreign Language Film  _(support: 5)_
- examples: Best Foreign Language Film; Best foreign language film

## 130. Best Actress, TV Drama  _(support: 5)_
- examples: Best Actress, TV Drama

## 131. best actress in TV drama for her work on  _(support: 5)_
- examples: best actress in TV drama for her work on

## 132. Best Animated Feature Film  _(support: 5)_
- examples: Best Animated Feature Film; best Animated Feature Film

## 133. Best Director at the Golden Globes  _(support: 5)_
- examples: Best Director at the Golden Globes

## 134. Best Actor, Comedy/Musical  _(support: 5)_
- examples: Best Actor, Comedy/Musical

## 135. best picture – comedy or musical http  _(support: 5)_
- examples: best picture - comedy or musical http

## 136. best actor for Les Miserables  _(support: 5)_
- examples: best actor for Les Miserables

## 137. best actor for Lincoln  _(support: 5)_
- examples: best actor for Lincoln

## 138. Best Comedy/Musical Movie http  _(support: 5)_
- examples: Best Comedy/Musical Movie http

## 139. Best Actress in a Television Series  _(support: 4)_
- examples: Best Actress in a TV series; Best Actress in a TV Series; Best Actress in a Television Series; best actress in a TV series

## 140. Best Actress in a Mini Series or TV Movie  _(support: 4)_
- examples: Best Actress in a Mini Series or TV Movie; Best Actress in a Mini Series or TV movie

## 141. Best Actress in a miniseries or TV movie  _(support: 4)_
- examples: Best Actress in a miniseries or TV movie; BEST ACTRESS IN A MINISERIES OR TV MOVIE; Best actress in a miniseries or TV movie

## 142. Best Comedy  _(support: 4)_
- examples: Best Comedy; best comedy

## 143. Best Picture tonight  _(support: 4)_
- examples: Best Picture tonight

## 144. best actor in a TV drama for  _(support: 4)_
- examples: best actor in a TV drama for

## 145. Best TV Series  _(support: 4)_
- examples: Best TV Series; best TV series; Best tv series

## 146. best score at the  _(support: 4)_
- examples: best score at the

## 147. Best Original Song Motion Picture  _(support: 4)_
- examples: Best Original Song Motion Picture

## 148. Best speech of the night  _(support: 4)_
- examples: Best speech of the night; Best Speech of the night

## 149. Best Actor in a Miniseries or Motion Picture Made for Television for Hatfields &amp  _(support: 4)_
- examples: Best Actor in a Miniseries or Motion Picture Made for Television for Hatfields &amp

## 150. Best Actor in a Miniseries or TV Movie for  _(support: 4)_
- examples: Best Actor in a Miniseries or TV Movie for

## 151. Best actress for comedy/musical  _(support: 4)_
- examples: Best actress for comedy/musical

## 152. best actress for Silver Linings Playbook  _(support: 4)_
- examples: best actress for Silver Linings Playbook; Best Actress for Silver Linings Playbook

## 153. best actress in a TV series drama http  _(support: 4)_
- examples: best actress in a TV series drama http

## 154. Best actress tv series comedy  _(support: 4)_
- examples: Best actress tv series comedy

## 155. Best Director for film Argo  _(support: 4)_
- examples: Best Director for film Argo

## 156. best actor, musical/comedy for  _(support: 4)_
- examples: best actor, musical/comedy for

## 157. Best Motion Picture for Comedy/Musical  _(support: 4)_
- examples: Best Motion Picture for Comedy/Musical

## 158. Best Actress for TV Comedy at Golden Globes  _(support: 4)_
- examples: Best Actress for TV Comedy at Golden Globes

## 159. best actress for Zero Dark Thirty  _(support: 4)_
- examples: best actress for Zero Dark Thirty; Best Actress for ZERO DARK THIRTY; Best Actress for Zero Dark Thirty

## 160. Best Motion Picture – Drama  _(support: 4)_
- examples: Best Motion Picture - Drama

## 161. Best Actor and Anne Hathaway wins Best Featured Actress for  _(support: 4)_
- examples: Best Actor and Anne Hathaway wins Best Featured Actress for

## 162. best facial hair of the night  _(support: 3)_
- examples: best facial hair of the night

## 163. Best Supporting Actress, TV for  _(support: 3)_
- examples: Best Supporting Actress, TV for

## 164. Best Support Actress in TV Movie, Series or Miniseries  _(support: 3)_
- examples: Best Support Actress in TV Movie, Series or Miniseries

## 165. best supporting actress for TV performance in  _(support: 3)_
- examples: best supporting actress for TV performance in

## 166. Best Actor in a Television Series, Drama, for Homeland  _(support: 3)_
- examples: Best Actor in a Television Series, Drama, for Homeland

## 167. best TV drama  _(support: 3)_
- examples: best TV drama; Best TV Drama

## 168. best drama  _(support: 3)_
- examples: best drama; Best Drama

## 169. best actress and first person to  _(support: 3)_
- examples: best actress and first person to

## 170. best drama on Golden Globes  _(support: 3)_
- examples: best drama on Golden Globes

## 171. Best Actor, TV movie or mini  _(support: 3)_
- examples: Best Actor, TV movie or mini

## 172. best actor in miniseries for  _(support: 3)_
- examples: best actor in miniseries for

## 173. Best Actress Motion Picture Comedy or Musical for Silver Linings Playbook  _(support: 3)_
- examples: Best Actress Motion Picture Comedy or Musical for Silver Linings Playbook

## 174. Best Actress, makes sassy  _(support: 3)_
- examples: Best Actress, makes sassy

## 175. best actress for Silver Linings  _(support: 3)_
- examples: best actress for Silver Linings

## 176. best actress for musical  _(support: 3)_
- examples: best actress for musical

## 177. Best Supporting Actress at  _(support: 3)_
- examples: Best Supporting Actress at; best supporting actress at

## 178. Best Screenplay – Motion Picture  _(support: 3)_
- examples: Best Screenplay - Motion Picture

## 179. best original screenplay  _(support: 3)_
- examples: best original screenplay

## 180. Best Screenplay, motion picture  _(support: 3)_
- examples: Best Screenplay, motion picture; Best Screenplay, Motion Picture

## 181. Best Actor in a Comedy  _(support: 3)_
- examples: Best Actor in a Comedy; Best Actor in a comedy

## 182. best foreign film http  _(support: 3)_
- examples: best foreign film http

## 183. Best speech  _(support: 3)_
- examples: Best speech; Best #GoldenGlobes speech

## 184. Best Actress in a TV Series/Drama for  _(support: 3)_
- examples: Best Actress in a TV Series/Drama for

## 185. best actress in a drama  _(support: 3)_
- examples: best actress in a drama; Best Actress in a Drama; Best Actress In A Drama

## 186. Best Animated Film  _(support: 3)_
- examples: Best Animated Film

## 187. best performance by an actress in a TV musical or comedy for  _(support: 3)_
- examples: best performance by an actress in a TV musical or comedy for

## 188. Best Movie  _(support: 3)_
- examples: Best Movie; best movie

## 189. Best Actor In A TV Movie At The Golden Globes http  _(support: 3)_
- examples: Best Actor In A TV Movie At The Golden Globes http

## 190. best director at the  _(support: 3)_
- examples: best director at the; Best Director at the

## 191. best director for awesome Argo  _(support: 3)_
- examples: best director for awesome Argo

## 192. best TV series, musical or comedy, at the  _(support: 3)_
- examples: best TV series, musical or comedy, at the

## 193. Best Comedy Series at the Globes  _(support: 3)_
- examples: Best Comedy Series at the Globes

## 194. best actor in a comedy/musical for Les Miserables  _(support: 3)_
- examples: best actor in a comedy/musical for Les Miserables; Best Actor in a Comedy/Musical for Les Miserables

## 195. Best Actor, Comedy or Musical  _(support: 3)_
- examples: Best Actor, Comedy or Musical; best actor, comedy or musical

## 196. best actor in a motion picture, comedy or musical for  _(support: 3)_
- examples: best actor in a motion picture, comedy or musical for; Best Actor in a Motion Picture, Comedy or Musical for

## 197. Best Director – Motion Picture – for Argo http  _(support: 3)_
- examples: Best Director - Motion Picture- for Argo http

## 198. Best Motion Picture – Comedy or Musical  _(support: 3)_
- examples: Best Motion Picture - Comedy or Musical; Best motion picture - comedy or musical

## 199. Best Motion Picture – Comedy or Musical at  _(support: 3)_
- examples: Best Motion Picture - Comedy or Musical at

## 200. Best Motion Picture, Comedy/Musical  _(support: 3)_
- examples: Best Motion Picture, Comedy/Musical

## 201. Best Actress Drama  _(support: 3)_
- examples: Best Actress Drama

## 202. Best Actor – Drama  _(support: 3)_
- examples: Best Actor - Drama

## 203. Best Actor In A Musical Or Comedy http  _(support: 3)_
- examples: Best Actor In A Musical Or Comedy http

## 204. best lead actor in a drama for  _(support: 3)_
- examples: best lead actor in a drama for

## 205. Best Picture – Drama  _(support: 3)_
- examples: Best Picture - Drama

## 206. Best Motion Picture – Comedy Or Musical http  _(support: 3)_
- examples: Best Motion Picture - Comedy Or Musical http

## 207. best movie honors at  _(support: 3)_
- examples: best movie honors at

# Predicted Golden Globes Winners (from candidates.json)

| Award | Winner | Votes | Share | Note |
|---|---|---:|---:|---|
| #BestActor in a #Drama for #Lincoln at the #GoldenGlobes | Louie | 1/1 | 100% |  |
| #BestActor in a Tv series Drama #GoldenGlobes | SteveBuscemi | 1/1 | 100% |  |
| #BestActress Tv series Drama #GoldenGlobes | GlennClose | 1/1 | 100% |  |
| #BestDirector AGAIN for #Argo at the #GoldenGlobes – #Academy Argofuck Yourself | BenAffleck | 1/1 | 100% |  |
| #BestForeignFilm at the #GoldenGlobes Which Is No Surprise Since It Was Nominated for the #AcademyAward for #BestPicture | Amour | 1/1 | 100% |  |
| And the Award for Cutest Besties | Loveit | 1/1 | 100% |  |
| BEST ACTOR in a MOTION PICTURE, MUSICAL or COMEDY | HUGH JACKMAN | 1/1 | 100% |  |
| BEST ACTRESS for Homeland Golden Globes 2013 Via | Claire Danes | 1/1 | 100% |  |
| Best 'or Musical | Les Miz | 1/1 | 100% |  |
| Best Acceptance Speech | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Accessory of the Night | Will Farrell | 1/1 | 100% |  |
| Best Actess in a TV series Drama | Claire Danes | 1/1 | 100% |  |
| Best Acting Awards at the | Jessica Chastain | 1/1 | 100% |  |
| Best Actor | Daniel Day-Lewis | 7/14 | 50% | ⚠️ low confidence |
| Best Actor As Well | Lincoln | 1/1 | 100% |  |
| Best Actor Award This Year Even Before Lincoln Came Out | Daniel Day Lewis | 1/1 | 100% |  |
| Best Actor Award for the Movie Lincoln at the | Daniel Day Lewis | 1/1 | 100% |  |
| Best Actor Comedy/Musical for Les Mis | Hugh Jackman | 2/2 | 100% |  |
| Best Actor Drama for Homeland | Damien Lewis | 1/1 | 100% |  |
| Best Actor From a Mini – series Kevin Costner Doesn | Bill Clinton | 1/1 | 100% |  |
| Best Actor I Might Go Pour Another Cocktail | Daniel Day Lewis | 1/1 | 100% |  |
| Best Actor In A Musical Or Comedy http | Hugh Jackmans | 1/1 | 100% |  |
| Best Actor In A TV Movie At The Golden Globes http | John McCain Ed Harris | 3/3 | 100% |  |
| Best Actor Mini series / TV Movie | Kevin Costner | 1/1 | 100% |  |
| Best Actor Musical or Comedy | Hugh Jackman | 1/1 | 100% |  |
| Best Actor So I Might As Well Go to Bed | Huge Jackmans | 1/1 | 100% |  |
| Best Actor TV Comedy series for HOUSE of LIES | Don Cheadle | 1/1 | 100% |  |
| Best Actor TV Drama Award | Damian Lewis | 1/1 | 100% |  |
| Best Actor TV series for Drama for Homeland, Was Rooting for Jeff Daniels, But Hey | Damian Lewis | 1/1 | 100% |  |
| Best Actor TV series or Drama | Damien Lewis | 1/1 | 100% |  |
| Best Actor TV series or Drama for Homeland | Damian Lewis | 1/1 | 100% |  |
| Best Actor When It Comes Down to It | Django | 1/1 | 100% |  |
| Best Actor and Actress Respectively in Drama series | Carrie | 1/1 | 100% |  |
| Best Actor and Anne Hathaway wins Best Featured Actress for | Hugh Jackman | 3/3 | 100% |  |
| Best Actor at | Hugh Jackman | 1/1 | 100% |  |
| Best Actor at Golden Globes | Damian Lewis | 1/1 | 100% |  |
| Best Actor at the | Bradley Cooper | 1/1 | 100% |  |
| Best Actor for Comedy/musical in the Miserables | Hugh Jackman | 1/1 | 100% |  |
| Best Actor for Faking His Own Death | Jesus | 1/1 | 100% |  |
| Best Actor for Game Change But He | Ed Harris | 1/1 | 100% |  |
| Best Actor for Hatfields &amp | Kevin Costner | 1/1 | 100% |  |
| Best Actor for His Powerful Role in Les Miserables | Hugh Jackman | 1/1 | 100% |  |
| Best Actor for Homeland, Dedicated the Award to His Mother | Damian Lewis | 1/1 | 100% |  |
| Best Actor for Les Mis | Hugh Jackman | 1/1 | 100% |  |
| Best Actor for Les Mis – –  Well Earned | Hugh Jackman | 1/1 | 100% |  |
| Best Actor for Lincoln – Motion Picture Drama | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor for Performance in | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor for TV series Comedy or Musical | Don Cheadle | 1/1 | 100% |  |
| Best Actor for TV series Drama | Damian Lewis | 1/1 | 100% |  |
| Best Actor for the Movie | GoldenGlobes | 1/1 | 100% |  |
| Best Actor in Comedy | Don Cheadle | 1/1 | 100% |  |
| Best Actor in Drama, As World Collectively Says | Daniel Day Lewis | 1/1 | 100% |  |
| Best Actor in Miniseries for Hatfields &amp | Kevin Costner | 1/1 | 100% |  |
| Best Actor in Motion Picture | Hugh Jackman | 1/1 | 100% |  |
| Best Actor in Musical or Comedy | Hugh Jackman | 1/1 | 100% |  |
| Best Actor in TV Series/Comedy or Musical | Don Cheadle | 1/1 | 100% |  |
| Best Actor in TV series | Damian Lewis | 1/1 | 100% |  |
| Best Actor in TV series – Drama | Damian Lewis | 1/1 | 100% |  |
| Best Actor in Tv series Drama Golden Globes 2013 Http | Damian Lewis | 1/1 | 100% |  |
| Best Actor in a Comedy | Don Cheadle | 2/2 | 100% |  |
| Best Actor in a Comedy film | Hugh Jackman | 1/1 | 100% |  |
| Best Actor in a Comedy/Musical | Hugh Jackman | 1/1 | 100% |  |
| Best Actor in a Comedy/musical I | Hugh Jackman | 1/1 | 100% |  |
| Best Actor in a Drama | Damian Lewis | 1/1 | 100% |  |
| Best Actor in a Drama for | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor in a Drama for His Masterful Performance in | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor in a Drama series at the Golden Globes Http | Damian Lewis | 1/1 | 100% |  |
| Best Actor in a Drama, Hands Down | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor in a Mini – Series/TV Movie at the | Kevin Costner | 1/1 | 100% |  |
| Best Actor in a Miniseries for | Kevin Costner | 1/1 | 100% |  |
| Best Actor in a Miniseries for the History Channel | Kevin Costner | 2/2 | 100% |  |
| Best Actor in a Miniseries or Motion Picture Made for Television | Kevin Costner | 1/1 | 100% |  |
| Best Actor in a Miniseries or Motion Picture Made for Television for Hatfields &amp | Kevin Costner | 2/2 | 100% |  |
| Best Actor in a Miniseries or TV Movie | Kevin Costner | 2/2 | 100% |  |
| Best Actor in a Motion Picture | GoldenGlobes | 2/3 | 67% |  |
| Best Actor in a Motion Picture Drama | Daniel Day-Lewis | 4/8 | 50% | ⚠️ low confidence |
| Best Actor in a Motion Picture Drama Http | Daniel Day Lewis | 1/1 | 100% |  |
| Best Actor in a Motion Picture Drama Is | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor in a Motion Picture Drama for Lincoln | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor in a Motion Picture Musical or Comedy for Les Mis | Hugh Jackman | 1/1 | 100% |  |
| Best Actor in a Motion Picture for Drama | Daniel Day Lewis | 1/1 | 100% |  |
| Best Actor in a Motion Picture in the Comedy or Musical Category for Les Miserables | GoldenGlobes | 1/1 | 100% |  |
| Best Actor in a Motion Picture in the Drama Category for Lincoln | Daniel Day Lewis | 1/1 | 100% |  |
| Best Actor in a Motion Picture – Drama | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor in a Motion Picture, Comedy/musical | Hugh Jackman | 1/1 | 100% |  |
| Best Actor in a Motion Picture, Drama | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor in a Motion Picture, Drama for | Daniel Day-Lewis | 2/3 | 67% |  |
| Best Actor in a Movie, Musical or Comedy | Hugh Jackman | 1/1 | 100% |  |
| Best Actor in a TV Comedy/musical | Don Cheadle | 1/1 | 100% |  |
| Best Actor in a TV Drama Award | Damian Lewis | 1/1 | 100% |  |
| Best Actor in a TV Miniseries | Kevin Costner | 1/1 | 100% |  |
| Best Actor in a TV Miniseries/Movie at the 2013 Http | Kevin Costner | 1/1 | 100% |  |
| Best Actor in a TV Series, Comedy for | Lena Dunham | 4/5 | 80% |  |
| Best Actor in a TV Series/Comedy for | Lena Dunham | 1/1 | 100% |  |
| Best Actor in a TV Show | Jon Hamm | 1/1 | 100% |  |
| Best Actor in a TV series | Don Cheadle | 1/1 | 100% |  |
| Best Actor in a TV series for | Don Cheadle | 1/1 | 100% |  |
| Best Actor in a TV series for His Role in Homeland | Damien Lewis | 1/1 | 100% |  |
| Best Actor in a TV series – Comedy | Don Cheadle | 1/1 | 100% |  |
| Best Actor in a TV series – Comedy or Musical | Don Cheadle | 1/1 | 100% |  |
| Best Actor in a Television Series, Comedy or Musical for His Role on House of Lies | YES!!@nbc | 1/1 | 100% |  |
| Best Actor in a Television series in a Comedy or Musical | Don Cheadle | 1/1 | 100% |  |
| Best Actor in a comedy or musical | Hugh Jackman | 1/1 | 100% |  |
| Best Actor in a film Golden Globes 2013 Via | Hugh Jackman | 1/1 | 100% |  |
| Best Actor – Comedy or Musical | GoldenGlobes | 1/1 | 100% |  |
| Best Actor – Drama | Daniel Day Lewis | 1/1 | 100% |  |
| Best Actor – Drama for Lincoln | Daniel Day-Lewis | 1/1 | 100% |  |
| Best Actor – in a Motion Picture | Daniel Day Lewis | 1/1 | 100% |  |
| Best Actor, Comedy or Musical | Golden Globes | 1/1 | 100% |  |
| Best Actor, Drama | Daniel Day-Lewis | 24/28 | 86% |  |
| Best Actor, TV Comedy Award for Showtime | Golden Globes | 1/1 | 100% |  |
| Best Actor, TV movie or mini | Kevin Costner | 1/1 | 100% |  |
| Best Actor, TV series Drama | Damian Lewis | 1/1 | 100% |  |
| Best Actress | Jessica Chastain | 9/20 | 45% | ⚠️ low confidence |
| Best Actress Award | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress Comedy | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress Comedy Movie | Bill Clinton | 1/1 | 100% |  |
| Best Actress Comedy or Musical | Jennifer Lawrence | 2/2 | 100% |  |
| Best Actress Comedy/Musical | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress Drama | Jessica Chastain | 2/2 | 100% |  |
| Best Actress Drama for Zero Da | Jessica Chastain | 1/1 | 100% |  |
| Best Actress Hands Down | Claire Danes | 1/1 | 100% |  |
| Best Actress Http | Celebrity Live Golden Globes | 1/1 | 100% |  |
| Best Actress In A Supporting Role in a Motion Picture the | - Anne Hathaway | 1/2 | 50% | ⚠️ low confidence |
| Best Actress Is a TV Comedy series | Lena Dunham | 1/1 | 100% |  |
| Best Actress Motion Picture Comedy or Musical for Silver Linings Playbook | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress Motion Picture Drama | Jessica Chastain | 1/1 | 100% |  |
| Best Actress Motion Picture for | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress TV series Drama | Claire Danes | 1/1 | 100% |  |
| Best Actress TV series – Drama for | RT @BBCNewsUS | 1/1 | 100% |  |
| Best Actress TV – Drama | Claire Danes | 1/1 | 100% |  |
| Best Actress and Looks Gorgeous Icy Blue Calvin Klein | Jessica Chastain | 1/1 | 100% |  |
| Best Actress at the Golden Globes | Jennifer Lawrence | 1/2 | 50% | ⚠️ low confidence |
| Best Actress for Drama for the Movie ZERO DARK THIRTY | Jessica Chastain | 1/1 | 100% |  |
| Best Actress for Homeland | Claire Danes | 2/3 | 67% |  |
| Best Actress for TV Comedy at Golden Globes | Lena Dunham | 4/4 | 100% |  |
| Best Actress for TV Comedy at Golden Globes Http | Lena Dunham | 1/1 | 100% |  |
| Best Actress for TV Series,musical or Comedy | Lena Dunham | 1/1 | 100% |  |
| Best Actress for a Motion Picture Drama | Jessica Chastain | 1/1 | 100% |  |
| Best Actress in Comedy or Musical in film | Lawrence | 1/1 | 100% |  |
| Best Actress in Comedy/Musical for | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress in Dramatic Movie | GoldenGlobes | 1/1 | 100% |  |
| Best Actress in GIRLS | Anne Hathaway | 1/1 | 100% |  |
| Best Actress in Mini – series at Golden Globes Http | Julianne Moore | 1/1 | 100% |  |
| Best Actress in Motion Picture – Drama | Jessica Chastain | 1/1 | 100% |  |
| Best Actress in TV | Lena Dunham | 1/1 | 100% |  |
| Best Actress in TV Comedy/Musical | Lena D for Girls | 1/1 | 100% |  |
| Best Actress in a Comedy or Musical for | Lawrence | 3/5 | 60% |  |
| Best Actress in a Comedy series Http | Lena Dunham | 1/1 | 100% |  |
| Best Actress in a Comedy/Musical for the AMAZING Silver Linings Playbook | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress in a Drama Television series | Claire Danes | 1/1 | 100% |  |
| Best Actress in a Miniseries or Made for TV Movie at the | Julianne Moore | 1/1 | 100% |  |
| Best Actress in a Miniseries or Made for TV Movie at the Golden Globes | Julianne Moore | 1/1 | 100% |  |
| Best Actress in a Miniseries or TV Movie for | Julianne Moore | 1/1 | 100% |  |
| Best Actress in a Motion Picture | Jennifer Lawrence | 2/3 | 67% |  |
| Best Actress in a Motion Picture Musical/Comedy | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress in a Motion Picture – Comedy for Silver Linings Playbook Http | Jennifer Lawrence | 2/2 | 100% |  |
| Best Actress in a Motion Picture – Drama | Jessica Chastain | 2/2 | 100% |  |
| Best Actress in a Motion Picture – Drama at the | Jessica Chastain | 1/1 | 100% |  |
| Best Actress in a Motion Picture, Comedy or Musical | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress in a Motion Picture, Drama | Jessica Chastain | 1/1 | 100% |  |
| Best Actress in a Motion Picture, Drama for | Jessica Chastain | 2/2 | 100% |  |
| Best Actress in a Motion Picture, Drama, for | Jessica Chastain | 1/1 | 100% |  |
| Best Actress in a Motion Picture, Drama, for Zero Dark Thirty | Jessica Chastain | 1/1 | 100% |  |
| Best Actress in a Motion Picture, Musical or Comedy Http | Golden Globes | 1/1 | 100% |  |
| Best Actress in a Movie | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress in a Movie for | Jessica Chastain | 1/1 | 100% |  |
| Best Actress in a Musical or Comedy | Jennifer Lawrence | 1/2 | 50% | ⚠️ low confidence |
| Best Actress in a Musical or Comedy Golden Globes 2013 | Http://t.co/3IyTTqP4 Lawrence | 1/1 | 100% |  |
| Best Actress in a Musical or Comedy Golden Globes 2013 http | Jennifer Lawrence | 3/3 | 100% |  |
| Best Actress in a Musical or Comedy Http | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress in a TV Comedy | Lena Dunham | 2/2 | 100% |  |
| Best Actress in a TV Drama at the | Claire Danes | 1/1 | 100% |  |
| Best Actress in a TV Miniseries or Motion Picture Made | Julianne Moore | 1/1 | 100% |  |
| Best Actress in a TV Miniseries or Movie | Julianne Moore | 1/1 | 100% |  |
| Best Actress in a TV Series, Comedy/Musical Thanks to | Lena Dunham | 1/1 | 100% |  |
| Best Actress in a TV Series, Drama for | Claire Danes | 2/2 | 100% |  |
| Best Actress in a TV Series, Drama, for Her Role in Homeland | Claire Danes | 1/1 | 100% |  |
| Best Actress in a TV series Comedy/musical | GoldenGlobes | 1/1 | 100% |  |
| Best Actress in a TV series Drama | Claire Danes | 1/1 | 100% |  |
| Best Actress in a TV series Drama for Homeland | Claire Danes | 1/1 | 100% |  |
| Best Actress in a TV series – Comedy or Musical for Girls | Lena Dunham | 1/1 | 100% |  |
| Best Actress in a TV series – Drama | Claire Danes | 1/1 | 100% |  |
| Best Actress in a Television Series | Claire Danes | 1/2 | 50% | ⚠️ low confidence |
| Best Actress in a Television Series, Drama, for Her Role on Homeland | Claire Danes | 1/1 | 100% |  |
| Best Actress in the Great Zero Dark 30 | Jessica Chastain | 1/1 | 100% |  |
| Best Actress – Drama, Motion Pitcure for Zero Dark Thirty | Jessica Chastain | 1/1 | 100% |  |
| Best Actress – Motion Picture – Comedy or Musical at Golden Globes | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress, | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress, Drama for ZERO DARK THIRTY | Jessica Chastain | 1/1 | 100% |  |
| Best Actress, Motion Picture Comedy or Musical for Silver Linings Playbook | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress, Motion Picture Comedy or Musical, for Silver Lining Playbook | Jennifer Lawrence | 1/1 | 100% |  |
| Best Actress, Motion Picture Drama | Jessica Chastain | 1/1 | 100% |  |
| Best Actress, Musical or Comedy Http | Golden Globes 2013 | 1/1 | 100% |  |
| Best Affair Ever | Bill Clinton | 1/1 | 100% |  |
| Best Animated Feature Film | GoldenGlobes | 3/3 | 100% |  |
| Best Animated Film | GoldenGlobes | 1/1 | 100% |  |
| Best Animated Picture Is So Well Deserved | GoldenGlobes | 1/1 | 100% |  |
| Best Animated film Globe | GoldenGlobes | 1/1 | 100% |  |
| Best Animated film Is | GoldenGlobes | 1/1 | 100% |  |
| Best Award Speech | Daniel Day Lewis | 1/1 | 100% |  |
| Best Awkward Girl You Avoid Talking to at a Party | Anne Hathaway | 1/1 | 100% |  |
| Best Awkward Moment | Salma Hayek | 1/1 | 100% |  |
| Best Beard on an Old Guy Who Played Inigo Montoya in | Mandy Patinkin | 1/1 | 100% |  |
| Best Bipartisan Freak Out Bait | Jessica Chastain | 1/1 | 100% |  |
| Best Bond Theme Ever | Adele | 1/1 | 100% |  |
| Best Cameo for an Award | Amy Poehler | 1/1 | 100% |  |
| Best Comedic Combo | Kristin | 1/1 | 100% |  |
| Best Comedy | @lenadunham | 1/3 | 33% | ⚠️ low confidence |
| Best Comedy / Musical | Congrats Les Mis | 1/1 | 100% |  |
| Best Comedy Actor In A Television Series | Don Cheadle | 16/16 | 100% |  |
| Best Comedy or Musical | Les Mis | 1/2 | 50% | ⚠️ low confidence |
| Best Comedy or Musicial | LesMiserables | 2/2 | 100% |  |
| Best Comedy series | Girls | 1/1 | 100% |  |
| Best Comedy/Musical | GoldenGlobes | 1/3 | 33% | ⚠️ low confidence |
| Best Comedy/Musical Motion Picture | Les Miserables | 1/1 | 100% |  |
| Best Comedy/Musical Movie http | Surya Golden Globes | 4/5 | 80% |  |
| Best Directing, He Got a Standing Ovation | Ben Affleck | 1/1 | 100% |  |
| Best Direction | Congrats | 1/1 | 100% |  |
| Best Director | Ben Affleck | 18/27 | 67% |  |
| Best Director &amp | Ben Affleck | 1/2 | 50% | ⚠️ low confidence |
| Best Director Award at Golden Globes | Ben Affleck | 1/1 | 100% |  |
| Best Director Award at Golden Globes for Argo | Ben Affleck | 1/1 | 100% |  |
| Best Director Award for | Ben Affleck | 1/2 | 50% | ⚠️ low confidence |
| Best Director Despite Oscar Snub Http | Ben Affleck | 1/1 | 100% |  |
| Best Director Http | Ben Affleck | 1/1 | 100% |  |
| Best Director and Best Picture for Argo | Oscar | 1/1 | 100% |  |
| Best Director and His Movie | Ben Affleck | 1/1 | 100% |  |
| Best Director and a standing ovation | Ben Affleck | 1/1 | 100% |  |
| Best Director at | Ben Affleck | 2/2 | 100% |  |
| Best Director at the Golden Globes | Ben Affleck | 2/2 | 100% |  |
| Best Director at the Golden Globes, But Is Not Nominated for a Oscar | Ben Afleck | 1/1 | 100% |  |
| Best Director for | Ben Affleck | 14/17 | 82% |  |
| Best Director for Argo | Ben Affleck | 8/10 | 80% |  |
| Best Director for Argo at | Ben Affleck | 1/1 | 100% |  |
| Best Director for Argo at Golden Globes 2013 | India Ben Affleck | 1/1 | 100% |  |
| Best Director for Argo at Golden Globes 2013 Http | Ben Affleck | 1/1 | 100% |  |
| Best Director for Argo at the | Ben Affleck | 1/1 | 100% |  |
| Best Director for Argo at the Golden Globes | Ben Affleck | 1/1 | 100% |  |
| Best Director for Argo in Golden Globes | Ben Affleck | 1/1 | 100% |  |
| Best Director for Reindeer Games 2 | Ben Affleck | 1/1 | 100% |  |
| Best Director for film Argo | Ben Affleck | 2/2 | 100% |  |
| Best Director for the ARGO film | Ben Afflect | 1/1 | 100% |  |
| Best Director of a Motion Picture | Ben Affleck | 1/1 | 100% |  |
| Best Director on These | Wanna | 1/1 | 100% |  |
| Best Director – But I | Django | 1/1 | 100% |  |
| Best Director – Motion Picture for Argo | Ben Affleck | 1/1 | 100% |  |
| Best Director, Motion Picture, for Argo | Ben Affleck | 1/1 | 100% |  |
| Best Disapperaing Act | Amy Pohler | 1/1 | 100% |  |
| Best Drama Http | Golden Globes | 1/1 | 100% |  |
| Best Drama Now | - Ben Affleck | 1/1 | 100% |  |
| Best Drama Please | Daniel Day Lewis | 1/1 | 100% |  |
| Best Drama TV Actress for | Claire Danes | 1/1 | 100% |  |
| Best Drama film Is | SHOCKED | 1/1 | 100% |  |
| Best Drama series | GoldenGlobes | 1/1 | 100% |  |
| Best Drama series Http | GoldenGlobes | 1/1 | 100% |  |
| Best Drama/Best Director at | Ben Affleck | 1/1 | 100% |  |
| Best Dress | Jennifer Lawrence | 1/1 | 100% |  |
| Best Dressed | Sofiavergara | 1/2 | 50% | ⚠️ low confidence |
| Best Dressed Wearing Miu Miu | Kerry Washington | 1/1 | 100% |  |
| Best Dressed and Best Eloquently Kick – Ass Acceptance Speech | Jessica Chastain | 1/1 | 100% |  |
| Best Dressed and Best Smile | John Krasinski | 1/1 | 100% |  |
| Best Dressed for Sure | Halle Berry | 1/1 | 100% |  |
| Best Dressed of the Night Easily | Kate Hudson | 1/1 | 100% |  |
| Best Drunken Acceptance Speech of the Night | GoldenGlobes | 1/1 | 100% |  |
| Best Eight Year Old Boy | Anne Hathaway | 1/1 | 100% |  |
| Best Everything | Jessica | 1/1 | 100% |  |
| Best Exotic Marigold Hotel | RT @TheMovieGuys | 1/1 | 100% |  |
| Best Face After Losing to Carrie Underwood | Sorry Taylor Swift | 1/1 | 100% |  |
| Best Facial Expression | Tommy Lee Jones | 1/1 | 100% |  |
| Best Film, Best Director | Affleck Oscar | 1/1 | 100% |  |
| Best Foreign Language | Michael Hanekes | 1/1 | 100% |  |
| Best Foreign Language Film | GoldenGlobes | 3/3 | 100% |  |
| Best Freckles in a Motion Picture, Musical or Comedy | Eddie Redmayne | 1/1 | 100% |  |
| Best Future GIF of the Night | Glenn Close | 1/1 | 100% |  |
| Best Gauze Bandage | Amanda Seyfried | 2/2 | 100% |  |
| Best Gay Porn Face | Benedict Cumberbatch | 1/1 | 100% |  |
| Best Golden Globes Acceptance Speech | Adele | 1/1 | 100% |  |
| Best Hair Award for the 2013 | Xxx | 1/1 | 100% |  |
| Best Hairstyle | GoldenGlobes | 1/1 | 100% |  |
| Best Husband at the | Hugh Jackman | 1/1 | 100% |  |
| Best Husband of the Year | Hugh Jackmon | 1/1 | 100% |  |
| Best Imitation of SNL | GoldenGlobes | 1/1 | 100% |  |
| Best Kanye Interruption at the | Anne Hathaway | 1/1 | 100% |  |
| Best Lesbian in a Back – Stage Candid Video Cameo | Jodie Foster | 1/1 | 100% |  |
| Best Live Action Role Since | Jack Black | 1/1 | 100% |  |
| Best Live Broadcast | GoldenGlobes | 1/1 | 100% |  |
| Best Male Actor in a Predominantly Gay Role, Then There Is No God | Leo | 1/1 | 100% |  |
| Best Mini Series/ TV Movie | GoldenGlobes | 1/1 | 100% |  |
| Best Mini series | Mc Coys | 1/1 | 100% |  |
| Best Mini series or TV Movie | GoldenGlobes | 2/2 | 100% |  |
| Best Mini – Actor in a series | Peter Dinklage | 1/1 | 100% |  |
| Best Mini – series or TV | GoldenGlobes | 1/1 | 100% |  |
| Best Miniseries or TV Movie Award | GoldenGlobes | 1/1 | 100% |  |
| Best Motion Picture | Les Miserables | 6/10 | 60% |  |
| Best Motion Picture Drama &amp | Ben | 1/1 | 100% |  |
| Best Motion Picture Screenplay | Quentin Tarantino | 1/1 | 100% |  |
| Best Motion Picture at | Les Miserables | 1/1 | 100% |  |
| Best Motion Picture for Comedy/Musical | Les Miserables | 2/2 | 100% |  |
| Best Motion Picture – Comedy Or Musical http | GoldenGlobes | 1/1 | 100% |  |
| Best Motion Picture – Comedy or Musical | GoldenGlobes | 2/4 | 50% | ⚠️ low confidence |
| Best Motion Picture – Comedy/Musical | Les Miserables | 1/1 | 100% |  |
| Best Motion Picture – Drama | Ben Affleck | 1/2 | 50% | ⚠️ low confidence |
| Best Motion Picture, Comedy or Musical, at the Golden Globes | Les Miserables | 1/1 | 100% |  |
| Best Motion Picture, Comedy/Musical | LesMiserables | 1/1 | 100% |  |
| Best Motion Picture, comedy or musical | Les Miserables | 3/4 | 75% |  |
| Best Movie | Django Unchained | 1/3 | 33% | ⚠️ low confidence |
| Best Movie Award | GoldenGlobes | 1/1 | 100% |  |
| Best Movie Comedy or Musical at the Golden Globes | Awesome Les Miserables | 1/1 | 100% |  |
| Best Movie Drama | GoldenGlobes RT | 1/1 | 100% |  |
| Best Movie I | Django | 1/1 | 100% |  |
| Best Movie – Comedy/Musical | LesMiz | 1/1 | 100% |  |
| Best Movie/Miniseries | GoldenGlobes | 1/1 | 100% |  |
| Best Musical | Goooo Les Miserables | 1/1 | 100% |  |
| Best Musical for the Golden Globes | Les Mis | 1/1 | 100% |  |
| Best Musical of Comedy | Les Miserables | 1/1 | 100% |  |
| Best Musical or Comedy After | Trifecta | 1/1 | 100% |  |
| Best Musical or Comedy Motion Picture | LesMiserables | 1/1 | 100% |  |
| Best Musical/comedy | Les Miserables | 1/2 | 50% | ⚠️ low confidence |
| Best Necklace | Jessica Alba | 1/1 | 100% |  |
| Best New Actor | Hugh Jackmans | 1/1 | 100% |  |
| Best Old Man Crush | Clooney | 1/1 | 100% |  |
| Best Original Score | Mychael Danna | 3/4 | 75% |  |
| Best Original Score for LIFE of PI | Michael Danna | 1/1 | 100% |  |
| Best Original Score for a film | Mychael Danna | 1/1 | 100% |  |
| Best Original Score, Motion Picture | Mychael Danna | 1/1 | 100% |  |
| Best Original Song | Adele | 6/13 | 46% | ⚠️ low confidence |
| Best Original Song Award | Adele | 1/1 | 100% |  |
| Best Original Song But Hey Ho It | Yeh | 1/1 | 100% |  |
| Best Original Song Goes to | Golden Globes 2013 | 1/1 | 100% |  |
| Best Original Song Goes to Skyfall 2013 Go | Golden Globes 2013 | 1/1 | 100% |  |
| Best Original Song Goes to Skyfall 2013 Golden Globes | Http://t.co/gFXC30Xj Golden Globes 2013 | 1/1 | 100% |  |
| Best Original Song Http | Golden Globes 2013 | 1/1 | 100% |  |
| Best Original Song I | Adele | 1/1 | 100% |  |
| Best Original Song Motion Picture | GoldenGlobes | 1/2 | 50% | ⚠️ low confidence |
| Best Original Song at the | Yuppp RT | 1/1 | 100% |  |
| Best Original Song at the Golden Globes Ill Be Pissed | Taylor | 1/1 | 100% |  |
| Best Original Song for Motion Picture | Taylor | 1/1 | 100% |  |
| Best Original Song for SkyFall Such an Awesome Singer and Person and Gave a Great Speech | Adele | 1/1 | 100% |  |
| Best Original Song for Skyfall | Yayyyy Adele | 1/1 | 100% |  |
| Best Original Song – Motion Picture | Skyfall Adeleeeeeeeee | 1/1 | 100% |  |
| Best Outfit of the Night | GoldenGlobes | 1/1 | 100% |  |
| Best Painted on Dress | Jennifer Lopez | 1/1 | 100% |  |
| Best Penguin Walking Impression | Tattooed Chick | 1/1 | 100% |  |
| Best Performance | GoldenGlobes | 1/1 | 100% |  |
| Best Performance by Don Cheadle in a Show Nobody Likes at All But It Has Don Cheadle in It So Whatever | Don Cheadle | 1/1 | 100% |  |
| Best Performance by an Actor in a Mini series or Movie Made for TV | Kevin Costner | 1/1 | 100% |  |
| Best Performance by an Actor in a Miniseries or TV Movie | Benedict Cumberbatch | 1/1 | 100% |  |
| Best Performance by an Actor in a Miniseries or TV film | Kevin Costner Hatfields & | 1/1 | 100% |  |
| Best Performance by an Actor in a Motion Picture, Comedy or Musical | Hugh Jackman | 1/1 | 100% |  |
| Best Performance by an Actress in a Comedy or Musical | Jennifer Lawrence | 1/1 | 100% |  |
| Best Performance by an Actress in a Motion Picture, Drama | Jessica Chastain | 1/1 | 100% |  |
| Best Performance by an Actress in a TV series at the | Julianne Moore | 1/1 | 100% |  |
| Best Performance by an Actress in a TV series – Musical or Comedy at the | Lena Dunham | 1/1 | 100% |  |
| Best Performance by an Actress in a Television series – Drama at the | Claire Danes | 1/1 | 100% |  |
| Best Performance in All the | Don Cheadle | 1/1 | 100% |  |
| Best Performance in TV series – Drama at the | Claire Danes | 1/1 | 100% |  |
| Best Performance in a Motion Picture for Les Miserables | Hugh Jackman | 1/1 | 100% |  |
| Best Peter Pan Haircut at the Golden Globes | Anne Hathaway | 1/1 | 100% |  |
| Best Pic | Les Mis | 1/1 | 100% |  |
| Best Picture As Well | GoldenGlobes | 1/1 | 100% |  |
| Best Picture Award | Bill Clinton | 1/1 | 100% |  |
| Best Picture Award Like the | Les Mis | 1/1 | 100% |  |
| Best Picture Awards Http | GoldenGlobes | 1/1 | 100% |  |
| Best Picture Comedy/Musical | Les Miserables | 1/1 | 100% |  |
| Best Picture Comedy/Musical at the | Les Miserables | 1/1 | 100% |  |
| Best Picture Drama, | Ben Affleck | 1/1 | 100% |  |
| Best Picture I Will Thrown Myself Off a Bridge | Les Mis | 1/1 | 100% |  |
| Best Picture Musical/Comedy | Les Miserables | 1/1 | 100% |  |
| Best Picture at the Oscars | Wanna | 1/1 | 100% |  |
| Best Picture for Comedy/Musical | Les Miserables | 1/1 | 100% |  |
| Best Picture nominee Lincoln | Bill Clinton | 1/1 | 100% |  |
| Best Picture – Comedy or Musical | Omg Omg Omg | 1/1 | 100% |  |
| Best Picture – Drama Http | Ben RT @washingtonpost | 1/1 | 100% |  |
| Best Picture, Comedy/Musical | Les Mis | 1/1 | 100% |  |
| Best Picture, Drama | RT @Variety | 1/1 | 100% |  |
| Best Political Shart | Al Roker | 1/1 | 100% |  |
| Best Presenters | Kristen Wiig | 1/1 | 100% |  |
| Best Presenters EVER | Will Ferrell | 1/1 | 100% |  |
| Best Presenters So Far | Will Ferrell | 1/1 | 100% |  |
| Best Punchline by an Actress | AMALAYERRRRR | 1/1 | 100% |  |
| Best Real Fraud President in USA HISTORY | Barry Soetoro | 1/1 | 100% |  |
| Best Real Life Quote Award | BILL CLINTON | 1/1 | 100% |  |
| Best Recovery From a J – Lo Relationship | Ben Affleck | 1/1 | 100% |  |
| Best Score for | RT @HuffPostEnt | 1/1 | 100% |  |
| Best Screenplay | Quentin Tarantino | 16/24 | 67% |  |
| Best Screenplay Motion Picture | Quentin Tarantino | 1/1 | 100% |  |
| Best Screenplay Well Deserved | Quentin Tarantino | 1/1 | 100% |  |
| Best Screenplay for Django Unchained Golden Globes 2013 Http | Quentin Tarantino | 1/1 | 100% |  |
| Best Screenplay for a Motion Picture | Quentin Taratino | 1/1 | 100% |  |
| Best Screenplay – Motion Picture | GoldenGlobes | 1/2 | 50% | ⚠️ low confidence |
| Best Screenplay – Motion Picture at the | Quentin Tarantino | 1/1 | 100% |  |
| Best Screenplay, motion picture | Quentin Tarantino | 2/2 | 100% |  |
| Best Screenplay, of Course | Quentin Tarantino | 1/1 | 100% |  |
| Best Shorn Locks | Bummer | 1/1 | 100% |  |
| Best Show on Television | Damian Lewis | 1/1 | 100% |  |
| Best Song | Adele | 2/4 | 50% | ⚠️ low confidence |
| Best Song at Golden Globes | RevistaBillboard Adele | 2/2 | 100% |  |
| Best Song at the | Adele | 1/2 | 50% | ⚠️ low confidence |
| Best Song at the Golden Globes for Skyfall | Adele | 2/2 | 100% |  |
| Best Song for WE | Madonna | 1/1 | 100% |  |
| Best Song for the Theme to Skyfall and Dame Maggie Smith Wi | Leimo Adele | 1/1 | 100% |  |
| Best Song, unsurprisingly | Adele | 1/1 | 100% |  |
| Best Speech Writer | Mel Gibson | 1/1 | 100% |  |
| Best Speech of the Night So Far | Jennifer Lawrence | 1/1 | 100% |  |
| Best Supp | Christoph Waltz | 1/1 | 100% |  |
| Best Suppor | Les Misérables | 2/2 | 100% |  |
| Best Supportin | Gossip | 1/1 | 100% |  |
| Best Supportin Actor at Golden Globes Http | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor Award | Christoph Waltz | 2/2 | 100% |  |
| Best Supporting Actor Award Like He Did Inglorious Basterds | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor Globe for | Christoph Waltz | 8/9 | 89% |  |
| Best Supporting Actor Http | Golden Globes | 1/1 | 100% |  |
| Best Supporting Actor at Golden Globes | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor at Golden Globes 2013 Http | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor at the 2002 Golden Globes | George W. Bush | 1/1 | 100% |  |
| Best Supporting Actor at the Golden Globes 2013 | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor at the Golden Globes 2013 Http | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor for Django | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor for Django Unchained | Christoph Waltz | 6/7 | 86% |  |
| Best Supporting Actor for Django Unchained Http | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor for His Role in Django Unchained | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor in | Christoph Waltz | 3/3 | 100% |  |
| Best Supporting Actor in Django Unchained | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor in a Motion Picture | Christoph Waltz | 2/2 | 100% |  |
| Best Supporting Actor in a Movie | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor in a TV Show, Miniseries or TV Movie Award | Ed Harris | 1/1 | 100% |  |
| Best Supporting Actor in a TV series | Ed Harris | 1/2 | 50% | ⚠️ low confidence |
| Best Supporting Actor in a TV series or Movie | Ed Harris | 1/1 | 100% |  |
| Best Supporting Actor in a series – I Like Ed Harris But Mandy Patinkin Was Robbed | GoldenGlobes Ed Harris | 1/1 | 100% |  |
| Best Supporting Actor – Motion Picture for His Work in | Christoph Waltz | 1/1 | 100% |  |
| Best Supporting Actor, But I | Leo | 1/1 | 100% |  |
| Best Supporting Actor, TV Movie, for Game Change, in Absentia | GoldenGlobes Ed Harris | 1/1 | 100% |  |
| Best Supporting Actor, TV series or Mini – Series, HBO | Ed Harris | 1/1 | 100% |  |
| Best Supporting Actress &amp | MaggieSmith | 1/1 | 100% |  |
| Best Supporting Actress XD | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress at Golden Globes 2013 | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress for Her Role in Les Mis – Looking Good for an Oscar Win Now Too | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress for Her Work in | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress for Les Mis | Anne Hathaway | 2/2 | 100% |  |
| Best Supporting Actress for Les Miserables | Anne Hathaway | 3/3 | 100% |  |
| Best Supporting Actress for TV | Maggie Smith | 1/1 | 100% |  |
| Best Supporting Actress for TV, Miniseries, Etc | Maggie Smith | 1/1 | 100% |  |
| Best Supporting Actress in | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress in TV Series, Mini – series or TV Movie | Maggie Smith | 1/1 | 100% |  |
| Best Supporting Actress in a Comedy or Musical | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress in a Drama | Maggie Smith | 1/1 | 100% |  |
| Best Supporting Actress in a Miniseries for Downton Abbey | Maggie Smith | 1/1 | 100% |  |
| Best Supporting Actress in a Motion Picture Drama | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress in a Motion Picture for | Anne Hathaway | 3/3 | 100% |  |
| Best Supporting Actress in a Motion Picture with Les Miserables | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress in a Motion Picture – Les Miserables | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress in a TV Movie, Series, or Miniseries | Maggie Smith | 1/1 | 100% |  |
| Best Supporting Actress in a TV Movie, Series, or Miniseries for | MaggieSmith | 1/1 | 100% |  |
| Best Supporting Actress in a TV Series | Maggie Smith | 2/2 | 100% |  |
| Best Supporting Actress in a TV Show, Miniseries or TV Movie | Maggie Smith | 1/1 | 100% |  |
| Best Supporting Actress – Les Miserables | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress – Motion | Les Misérables | 1/1 | 100% |  |
| Best Supporting Actress, | Anne Hathaway | 1/1 | 100% |  |
| Best Supporting Actress, TV for | Maggie Smith | 1/1 | 100% |  |
| Best Supporting Actress, and I | Maggie Smith | 1/1 | 100% |  |
| Best Supporting Band in a Comedy or Musical | GoldenGlobes | 1/1 | 100% |  |
| Best Supporting Ginger Who Also Makes My Panties Wet | Damian Lewis | 1/1 | 100% |  |
| Best Supporting Handjob | Amy Adams | 1/1 | 100% |  |
| Best TV Actor – Comedy, Tarantino Wins Screenplay Award | Don Cheadle | 2/2 | 100% |  |
| Best TV Actor – Drama | Damian Lewis | 1/1 | 100% |  |
| Best TV Actress | Lena Dunham | 1/1 | 100% |  |
| Best TV Actress in a Comedy From Girls | Jack | 1/1 | 100% |  |
| Best TV Movie | Sarah Palin | 1/2 | 50% | ⚠️ low confidence |
| Best TV Musical or Comedy for House of Lies Http | Don Cheadle | 1/1 | 100% |  |
| Best TV Series | GoldenGlobes | 2/4 | 50% | ⚠️ low confidence |
| Best TV Series – Drama | GoldenGlobes | 4/5 | 80% |  |
| Best TV Series, Comedy | 😃😃😃 RT @THR: | 1/1 | 100% |  |
| Best TV Series, Drama | YESSSS | 1/1 | 100% |  |
| Best TV comedy/musical | GoldenGlobes | 1/2 | 50% | ⚠️ low confidence |
| Best TV series Actress in a Comedy or Musical | Lena Dunham | 1/1 | 100% |  |
| Best TV series Drama | GoldenGlobes | 1/2 | 50% | ⚠️ low confidence |
| Best TV series Drama Http | Yessssssssss RT @washingtonpost | 1/1 | 100% |  |
| Best TV series – Comedy | GoldenGlobes | 1/1 | 100% |  |
| Best Tan by an Actress | Lea Michelle | 1/1 | 100% |  |
| Best Television Series, Comedy or Musical | GoldenGlobes | 1/1 | 100% |  |
| Best Television series Actor | Damien Lewis | 1/1 | 100% |  |
| Best Thank You to a Spouse | GoldenGlobes | 1/1 | 100% |  |
| Best Things That Will Happen Tonight | Daniel Craig | 1/1 | 100% |  |
| Best Use of a Large Doily | Jennifer Lopez | 1/1 | 100% |  |
| Best Wife | Ben Affleck | 1/1 | 100% |  |
| Best Win So Far | @lenadunham | 1/1 | 100% |  |
| Best actor TV series – comedy or musical | Don Cheadle | 1/1 | 100% |  |
| Best actor for TV drama | Zeebox | 1/2 | 50% | ⚠️ low confidence |
| Best actor in a miniseries/TV movie | Kevin Costner | 4/4 | 100% |  |
| Best actress for comedy/musical | Jennifer Lawrence | 2/2 | 100% |  |
| Best actress in a TV comedy or musical | Lena Dunham | 4/4 | 100% |  |
| Best actress in a TV comedy/musical | GoldenGlobes | 1/1 | 100% |  |
| Best actress in a motion picture drama | Jessica Chastain | 3/3 | 100% |  |
| Best director for motion picture | Ben Affleck | 3/6 | 50% | ⚠️ low confidence |
| Best director motion picture | Ben Affleck | 10/10 | 100% |  |
| Best film Director | Ben Affleck | 1/1 | 100% |  |
| Best foreign film | GoldenGlobes | 3/3 | 100% |  |
| Best motion picture drama | GoldenGlobes | 11/13 | 85% |  |
| Best on Set Catering | GoldenGlobes | 1/1 | 100% |  |
| Best original score – motion picture is | Joel Zimmerman | 1/2 | 50% | ⚠️ low confidence |
| Best speech | Jodie Foster | 1/2 | 50% | ⚠️ low confidence |
| Best speech of the night | Adele | 1/3 | 33% | ⚠️ low confidence |
| Best supporting actor in TV | Ed Harris | 4/4 | 100% |  |
| Best supporting actor, motion picture | Christoph Waltz | 7/7 | 100% |  |
| Best supporting actress TV series, miniseries, or TV movie | Maggie Smith | 2/2 | 100% |  |
| Best supporting actress in a motion picture is | Anne Hathaway | 16/17 | 94% |  |
| Bests Original Beard | GoldenGlobes | 1/1 | 100% |  |
| For #Skyfall, It's the Best #GoldenGlobes | Adele | 1/1 | 100% |  |
| best Best Television Comedy/Musical Series | GoldenGlobes | 2/3 | 67% |  |
| best TV drama | Sorry Downton | 1/2 | 50% | ⚠️ low confidence |
| best TV series – comedy or musical http | Girls | 2/2 | 100% |  |
| best TV series, musical or comedy, at the | Girls | 1/1 | 100% |  |
| best actor for | Daniel Day-Lewis | 4/7 | 57% |  |
| best actor for Les Miserables | GoldenGlobes Hugh | 1/2 | 50% | ⚠️ low confidence |
| best actor for TV drama http | Damian Lewis | 1/1 | 100% |  |
| best actor in a TV drama for | Damian Lewis | 2/2 | 100% |  |
| best actor in a comedy or musical TV series for | Don Cheadle | 2/2 | 100% |  |
| best actor in a comedy/musical for Les Miserables | Hugh Jackman | 1/1 | 100% |  |
| best actor in a drama for Lincoln at the | Daniel Day-Lewis | 2/2 | 100% |  |
| best actor in a miniseries | Kevin Costner | 1/1 | 100% |  |
| best actor in a motion picture, comedy or musical for | Hugh Jackman | 2/2 | 100% |  |
| best actor in a musical or comedy award at | Hugh Jackman | 2/2 | 100% |  |
| best actor in a musical/comedy | Hugh Jackman | 1/1 | 100% |  |
| best actor who did not have sex with that woman | Bill Clinton | 1/2 | 50% | ⚠️ low confidence |
| best actor, drama for | Daniel Day-Lewis | 3/3 | 100% |  |
| best actor, musical/comedy for | Hugh Jackman | 1/1 | 100% |  |
| best actress and first person to | Julianne Moore | 1/1 | 100% |  |
| best actress for | Jessica Chastain | 2/4 | 50% | ⚠️ low confidence |
| best actress for Silver Linings | Jennifer Lawrence | 1/1 | 100% |  |
| best actress for Zero Dark Thirty | Jessica Chastain | 2/2 | 100% |  |
| best actress in a TV series drama http | Claire Danes | 2/2 | 100% |  |
| best actress in a TV series – comedy or musical http | Lena Dunham | 1/1 | 100% |  |
| best actress in a comedy | Lena Dunham | 1/2 | 50% | ⚠️ low confidence |
| best actress in a comedy for Silver Linings Playbook | Jennifer Lawrence | 2/2 | 100% |  |
| best actress in a comedy or musical | Jennifer Lawrence | 1/2 | 50% | ⚠️ low confidence |
| best actress in a comedy or musical movie for | Jennifer Lawrence | 3/3 | 100% |  |
| best actress in a drama | Claire Danes | 1/2 | 50% | ⚠️ low confidence |
| best actress in a dramatic film for | Jessica Chastain | 4/4 | 100% |  |
| best actress in a mini – series or TV movie for | Julianne Moore | 1/1 | 100% |  |
| best actress in a musical/comedy for | Jennifer Lawrence | 1/1 | 100% |  |
| best actress in mini – series/TV movie for | Julianne Moore | 1/1 | 100% |  |
| best actress, drama, for | Jessica Chastain | 1/1 | 100% |  |
| best director at the | Ben Affleck | 3/3 | 100% |  |
| best director for awesome Argo | Ben Affleck | 1/1 | 100% |  |
| best drama | Breaking Bad Deserve | 1/3 | 33% | ⚠️ low confidence |
| best film director for | Ben Affleck | 1/1 | 100% |  |
| best foreign film at | Michael Haneke | 1/1 | 100% |  |
| best foreign film http | Amour | 1/1 | 100% |  |
| best lead actor in a drama for | Daniel Day-Lewis | 1/1 | 100% |  |
| best miniseries or TV movie | GoldenGlobes | 3/3 | 100% |  |
| best motion picture screenplay for | Quentin Tarantino | 3/3 | 100% |  |
| best original song for | Adele | 4/4 | 100% |  |
| best original song for motion picture http | Adele | 2/3 | 67% |  |
| best performance by an actress in a TV musical or comedy for | Lena Dunham | 1/1 | 100% |  |
| best picture | Les Miserables | 3/10 | 30% | ⚠️ low confidence |
| best picture – comedy or musical http | LesMis | 2/3 | 67% |  |
| best picture, musical or comedy | Les Miserables | 3/5 | 60% |  |
| best screenplay for | Quentin Tarantino | 6/6 | 100% |  |
| best screenplay for Django Unchained | Quentin Tarantino | 5/6 | 83% |  |
| best speech award | Jessica Chastain | 1/1 | 100% |  |
| best supporting actor | Christoph Waltz | 11/21 | 52% | ⚠️ low confidence |
| best supporting actor at | Christoph Waltz | 1/1 | 100% |  |
| best supporting actor for | Christoph Waltz | 2/3 | 67% |  |
| best supporting actress | Anne Hathaway | 8/11 | 73% |  |
| best supporting actress for | Anne Hathaway | 8/8 | 100% |  |
| best supporting actress for TV performance in | Maggie Smith | 1/1 | 100% |  |
| best supporting actress http | Anne Hathaway | 1/3 | 33% | ⚠️ low confidence |
| best – picture Golden Globes | Les Miz | 4/4 | 100% |  |
